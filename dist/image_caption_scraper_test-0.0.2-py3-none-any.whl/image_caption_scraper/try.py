from scraper import Image_Caption_Scraper

scraper = Image_Caption_Scraper()
scraper.scrape(save_images=True)